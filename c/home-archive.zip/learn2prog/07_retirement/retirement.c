#include <stdio.h>
#include <stdlib.h>

struct _retire_info {
    int months;
    double contribution;
    double rate_of_return;
} ;

typedef struct _retire_info retire_info;

void retirement (int startAge,   //in months
                 double initial, //initial savings in dollars
                 retire_info working, //info about working
                 retire_info retired) //info about being retired
{
    // at the end of the month
    int year =  startAge / 12;
    int month = startAge % 12;
    if (retired.months < 1) {
        return;
    }
    printf("Age %3d month %2d you have $%.2lf\n", year, month, initial);
    startAge++;

    if (working.months < 1) {
        retired.months--;
        initial += retired.contribution + initial * retired.rate_of_return;
        retirement(startAge, initial, working, retired);
    } else {
        working.months--;
        initial += working.contribution + initial * working.rate_of_return;
        retirement(startAge, initial, working, retired);
    }



}

int main () {
    retire_info working = {489, 1000, 0.045/12};


    retire_info retired = {384, -4000, 0.01/12};

    retirement(327, 21345, working, retired);
	return 0;
}

