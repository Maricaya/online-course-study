#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int getMatrix(FILE *f, char matrix[10][10]) {


    return EXIT_SUCCESS;
}

void rotate(char matrix[10][10]) {
    char a[10][10];
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            a[i][j] = matrix[9 - j][i];
        }
    }

    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            matrix[i][j] = a[i][j];
            printf("%c", matrix[i][j]);
        }
        printf("\n");
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: ./rotateMatrix inputFileName \n");
        return EXIT_FAILURE;
    }

    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
        fprintf(stderr, "Could not open file");
        return EXIT_FAILURE;
    }

    char matrix[10][10];

//    int check = getMatrix(f, matrix);
//
//    if (check == EXIT_FAILURE) {
//        return EXIT_FAILURE;
//    }

    const int expectedLines = 10;
    const int expectedCharsPerLine = 10;

    char line[256]; // 假设一行最多包含 255 个字符
    // 逐行读取文件内容
    int lineCount = 0;
    while (fgets(line, sizeof(line), f) != NULL) {
        if (strlen(line) != expectedCharsPerLine + 1) {
            fprintf(stderr, "The file format is incorrect");
            return EXIT_FAILURE;
        }

        for (int i = 0; i < 10; i++) {
            matrix[lineCount][i] = line[i];
        }

        lineCount++;
    }

    if (lineCount != expectedLines) {
        fprintf(stderr, "The file format is incorrect");
        return EXIT_FAILURE;
    }

    rotate(matrix);

    fclose(f);

    return EXIT_SUCCESS;
}
