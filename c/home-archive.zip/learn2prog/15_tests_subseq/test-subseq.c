#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <assert.h>

size_t maxSeq(int *array, size_t n);

int main(void) {
    size_t a;
    int array1[] = {77, 33, 19, 99, 42, 6, 27, 4};
    a = maxSeq(array1, 8);
    if (a != 2) {
        return EXIT_FAILURE;
    }

    int array2[100] = { -42, -99, -1000, -999, -88, -77, 't'};
    a = maxSeq(array2, 7);
    if (a != 5) {
        return EXIT_FAILURE;
    }

    array2[6] = -6;
    array2[10] = 100;
    a = maxSeq(array2, 7);
    if (a != 5) {
        return EXIT_FAILURE;
    }

    int array3[] = {425, 59, -3, 77, 0, 36, 1234};
    a = maxSeq(array3, 7);
    if (a != 3) {
        return EXIT_FAILURE;
    }

    int array4[] = {1, 0, -1, -2};
    a = maxSeq(array4, 4);
    if (a != 1) {
        return EXIT_FAILURE;
    }

    a = maxSeq(array4, 0);
    if (a != 0) {
        return EXIT_FAILURE;
    }

    a = maxSeq(NULL, 0);
    if (a != 0) {
        return EXIT_FAILURE;
    }

    int array5[] = {-42, -42,-42,-42};
    a = maxSeq(array5, 8);
    if (a != 2) {
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
