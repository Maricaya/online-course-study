#include <stdio.h>
#include <stdlib.h>
//I've provided "min" and "max" functions in
//case they are useful to you
int min (int a, int b) {
  if (a < b) {
    return a;
  }
  return b;
}
int max (int a, int b) {
  if (a > b) {
    return a;
  }
  return b;
}

//Declare your rectangle structure here!
typedef struct  {
    int x;
    int y;
    int width;
    int height;
} rectangle;

rectangle canonicalize(rectangle r) {
    if (r.width < 0) {
        r.x = r.x + r.width;
        r.width = abs(r.width);
    }

    if (r.height < 0) {
        r.y = r.y + r.height;
        r.height = abs(r.height);
    }

    return r;
}

//You should not need to modify any code below this line
void printRectangle(rectangle r) {
    r = canonicalize(r);
    if (r.width == 0 && r.height == 0) {
        printf("<empty>\n");
    } else {
        printf("(%d,%d) to (%d,%d)\n", r.x, r.y,
               r.x + r.width, r.y + r.height);
    }
}

rectangle intersection(rectangle r1, rectangle r2) {
    r1 = canonicalize(r1);
    r2 = canonicalize(r2);

    rectangle rRight = r1.x >= r2.x ? r1 : r2;
    rectangle rLeft = r1.x < r2.x ? r1 : r2;

    rectangle rTop = r1.y >= r2.y ? r1 : r2;
    rectangle rBottom = r1.y < r2.y ? r1 : r2;

    rectangle mix ={0,0,0,0};
    mix.x = rRight.x;
    mix.y = rTop.y;
    if (rRight.x + rRight.width <= rLeft.x + rLeft.width
    ) {
        mix.width = min(r1.width, r2.width);
    } else if (rRight.x <= rLeft.x + rLeft.width){
        mix.width = rLeft.x + rLeft.width - mix.x;
    }

    if (rTop.y+rTop.height <= rBottom.y+rBottom.height) {
        mix.height = min(r1.height, r2.height);
    } else if (rTop.y <= rBottom.y + rBottom.height){
        mix.height = rBottom.y + rBottom.height - mix.y;
    }

    if (rBottom.y+rBottom.height < rTop.y
    ||
        rLeft.x+rLeft.width < rRight.x
    ) {

        mix.height = 0;
        mix.width = 0;
    }


    return mix;
}

//int main(void) {
//    struct rectangle r2;
//    struct rectangle r3;
//
//    r2.x = 4;
//    r2.y = 5;
//    r2.width = -5;
//    r2.height = -7;
//    printf("r2 is ");
//    printRectangle(r2);
//
//    r3.x = -2;
//    r3.y = 7;
//    r3.width = 7;
//    r3.height = -10;
//    printf("r3 is ");
//    printRectangle(r3);
//
//    struct rectangle i = intersection(r2, r3);
//    printf("intersection(r2,r3): ");
//    printRectangle(i);
//}

int main(void) {
    rectangle r1;
    rectangle r2;
    rectangle r3;
    rectangle r4;

    r1.x = 2;
    r1.y = 3;
    r1.width = 5;
    r1.height = 6;
    printf("r1 is ");
    printRectangle(r1);

    r2.x = 4;
    r2.y = 5;
    r2.width = -5;
    r2.height = -7;
    printf("r2 is ");
    printRectangle(r2);

    r3.x = -2;
    r3.y = 7;
    r3.width = 7;
    r3.height = -10;
    printf("r3 is ");
    printRectangle(r3);

    r4.x = 0;
    r4.y = 7;
    r4.width = -4;
    r4.height = 2;
    printf("r4 is ");
    printRectangle(r4);

    //test everything with r1
    rectangle i = intersection(r1, r1);
    printf("intersection(r1,r1): ");
    printRectangle(i);

    i = intersection(r1, r2);
    printf("intersection(r1,r2): ");
    printRectangle(i);

    i = intersection(r1, r3);
    printf("intersection(r1,r3): ");
    printRectangle(i);

    i = intersection(r1, r4);
    printf("intersection(r1,r4): ");
    printRectangle(i);

    //test everything with r2
    i = intersection(r2, r1);
    printf("intersection(r2,r1): ");
    printRectangle(i);

    i = intersection(r2, r2);
    printf("intersection(r2,r2): ");
    printRectangle(i);

    i = intersection(r2, r3);
    printf("intersection(r2,r3): ");
    printRectangle(i);

    i = intersection(r2, r4);
    printf("intersection(r2,r4): ");
    printRectangle(i);

    //test everything with r3
    i = intersection(r3, r1);
    printf("intersection(r3,r1): ");
    printRectangle(i);

    i = intersection(r3, r2);
    printf("intersection(r3,r2): ");
    printRectangle(i);

    i = intersection(r3, r3);
    printf("intersection(r3,r3): ");
    printRectangle(i);

    i = intersection(r3, r4);
    printf("intersection(r3,r4): ");
    printRectangle(i);

    //test everything with r4
    i = intersection(r4, r1);
    printf("intersection(r4,r1): ");
    printRectangle(i);

    i = intersection(r4, r2);
    printf("intersection(r4,r2): ");
    printRectangle(i);

    i = intersection(r4, r3);
    printf("intersection(r4,r3): ");
    printRectangle(i);

    i = intersection(r4, r4);
    printf("intersection(r4,r4): ");
    printRectangle(i);

//    rectangle r5 = {0,0,1,1};
//    rectangle r6 = {-1, 1, 3, 2};
//    i = intersection(r5, r6); // 0,1,1,0
//    rectangle r7 = {0, 1, 1, 0};
//    printRectangle(r7);
//    printf("intersection(r5,r6): ");
//    printRectangle(i);


    return EXIT_SUCCESS;

}

