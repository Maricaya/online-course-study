#include <stdio.h>

size_t maxSeq(int * array, size_t n) {
    int max = 0;

    if (n == 0) {
        return max;
    }

    int c_max = 1;
    max = c_max;
    for (int i = 0; i < n;i++) {
        int j = i+1;
        if (j < n) {
            if (array[j] > array[i]) {
                c_max++;
            } else {
                c_max = 1;
            }
            if (c_max > max) {
                max = c_max;
            }
        }
    }
    return max;
}



