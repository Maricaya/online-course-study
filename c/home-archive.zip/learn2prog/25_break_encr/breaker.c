#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void decrypt(FILE *f, int *letterCount) {
    int c;
    while ((c = fgetc(f)) != EOF) {
        if (isalpha(c)) {
            c = tolower(c);
            c -= 'a';
            letterCount[c] = letterCount[c] + 1;
        }
    }
}

int getKey(int *letterCount) {
    int max = letterCount[0];
    int maxLetterIndex = 0;
    for (int i = 0; i < 26; i++) {
        if (letterCount[i] > max) {
            max = letterCount[i];
            maxLetterIndex = i;
        }
    }
    return maxLetterIndex;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: ./breaker inputFileName \n");
        return EXIT_FAILURE;
    }
    FILE *f = fopen(argv[1], "r");
    if (f == NULL) {
//        fprintf(stderr, "Failed to open file '%s'\n", argv[1]);
        perror("Could not open file");
        return EXIT_FAILURE;
    }

    int letterCount[26] = {0};
    decrypt(f, letterCount);

    int maxLetterIndex = getKey(letterCount);

    int key = (maxLetterIndex + 'a' - 'e' + 26) % 26;

    printf("%d\n", key);
}
