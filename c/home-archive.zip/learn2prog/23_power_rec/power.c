#include <limits.h>

unsigned power(unsigned x, unsigned y) {
    if ( y == 0) {
        return 1;
    }
    if (x == 0) { 
    	return 0;
    }
    if (y == 1) {
        return x;
    }

    if ( INT_MAX / x < (int) x) {
        if ((int) x > 0 ||  y % 2 == 0) {
            return INT_MAX;
        }
       return 0;
    }

    y = (int) y > 0 ? y - 1 : y + 1;
    return x * power(x, y);
}

