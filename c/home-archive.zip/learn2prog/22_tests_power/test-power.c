#include <stdio.h>
#include <stdlib.h>

unsigned power(unsigned x, unsigned y);

void run_check(unsigned x, unsigned y, unsigned expected_ans) {
    int a = power(x, y);
    // printf("x: %d, y: %d, answer: %d\n", x, y, a);
    if (a != expected_ans) {
        exit(EXIT_FAILURE);
    }
}

int main () {
    run_check(-1, -1, -1);

    run_check(0, 0, 1);

    run_check(0, 'a', 0);

    run_check(1, 0, 1);

    run_check(0, 1, 0);

    run_check('h', 1, 104);

    run_check(3, 9, 19683);

    run_check(2147483647, 2147483647, 2147483647);

    run_check(-2147483648, 2147483647, 0);

    run_check(2, 3, 8);

    run_check(5, 0, 1);

    run_check(10, 1, 10);

    run_check(1, 100, 1);

    run_check(10, 10, 1410065408);

    run_check(0, 1, 0);

    run_check(1, -1, 1);

    run_check(-2, 2, 4);

    run_check(-3, 3, -27);

    return EXIT_SUCCESS;
}
