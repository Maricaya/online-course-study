#include <stdio.h>
#include <stdlib.h>

unsigned power(unsigned x, unsigned y);

void run_check(unsigned x, unsigned y, unsigned expected_ans) {
    int a = power(x, y);
    if (a != expected_ans) {
        exit(EXIT_FAILURE);
    }
}

int main () {
    unsigned result = power(-1, -1);
    printf("Result: %u\n", result);
    result = power(0, 0);
    printf("Result: %u\n", result);
    result = power(0, 'a');
    printf("Result: %u\n", result);

    result = power(1, 0);
    printf("Result: %u\n", result);

    result = power(0, 1);
    printf("Result: %u\n", result);

    result = power('h', 1);
    printf("Result: %u\n", result);

    result = power(3, 9);
    printf("Result: %u\n", result);

    result = power(2147483647, 2147483647);
    printf("Result: %u\n", result);

    result = power(-2147483648, 2147483647);
    printf("Result: %u\n", result);


    return EXIT_SUCCESS;
}
