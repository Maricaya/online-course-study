#include <stdio.h>

void rotate(char matrix[10][10]) {
    char a[10][10];
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            a[i][j] = matrix[9-j][i];
            /* 0 0 =  9 0
            // 0 1 =  8 0
            // 0 2 =  7 0
            // ...
               0 9 =  0 0
               1 0 =  9 1
             */
        }
    }

    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            matrix[i][j] = a[i][j];
        }
    }
}

