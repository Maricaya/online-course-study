#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "cards.h"

void assert_card_valid(card_t c) {
    assert((c.value >= 2 && c.value <= 10) || c.value == VALUE_ACE || c.value == VALUE_KING || c.value == VALUE_QUEEN || c.value == VALUE_JACK);
    assert(c.suit == SPADES || c.suit == HEARTS || c.suit == DIAMONDS || c.suit == CLUBS);
}

const char * ranking_to_string(hand_ranking_t r) {
    switch (r) {
        case FOUR_OF_A_KIND:
            return "FOUR_OF_A_KIND";
        case STRAIGHT_FLUSH:
            return "STRAIGHT_FLUSH";
        case FULL_HOUSE:
            return "FULL_HOUSE";
        case FLUSH:
            return "FLUSH";
        case STRAIGHT:
            return "STRAIGHT";
        case THREE_OF_A_KIND:
            return "THREE_OF_A_KIND";
        case TWO_PAIR:
            return "TWO_PAIR";
        case PAIR:
            return "PAIR";
        case NOTHING:
            return "NOTHING";
        default:
            return "Invalid Ranking";
    }
}

//Hint: remember everything is a number.
//For example, the character '0' has the decimal value 48,
//and the character '5' has the decimal value 53, so you could represent
//'5' as '0' + 5.
char value_letter(card_t c) {
    char l;
    if (c.value == 2) {
        l = '2';
    } else if (c.value == 3) {
        l = '3';
    } else if (c.value == 4) {
        l = '4';
    } else if (c.value == 5) {
        l = '5';
    } else if (c.value == 6) {
        l = '6';
    } else if (c.value == 7) {
        l = '7';
    } else if (c.value == 8) {
        l = '8';
    } else if (c.value == 9) {
        l = '9';
    } else if (c.value == 10) {
        l = '0';
    } else if (c.value == 11) {
        l = 'J';
    } else if (c.value == 12) {
        l = 'Q';
    } else if (c.value == 13) {
        l = 'K';
    } else if (c.value == 14) {
        l = 'A';
    } else {
        l = '?'; // 可以添加默认情况的处理
    }
    return l;
}

char suit_letter(card_t c) {
    char l;
    if (c.suit == SPADES) {
        l = 's';
    } else if (c.suit == HEARTS) {
        l = 'h';
    } else if (c.suit == DIAMONDS) {
        l = 'd';
    } else if (c.suit == CLUBS) {
        l = 'c';
    } else {
        l = '?'; // 可以添加默认情况的处理
    }
    return l;
}

void print_card(card_t c) {
    char value = value_letter(c);
    char suit = suit_letter(c);

    printf("%c%c", value, suit);
}

card_t card_from_letters(char value_let, char suit_let) {
    card_t card;
    // 将字符表示的值转换为对应的数字值
    if (value_let >= '2' && value_let <= '9') {
        card.value = value_let - '0';
    } else {
        switch (value_let) {
            case 'T':
                card.value = 10;
                break;
            case 'J':
                card.value = 11;
                break;
            case 'Q':
                card.value = 12;
                break;
            case 'K':
                card.value = 13;
                break;
            case 'A':
                card.value = 14;
                break;
            case '0':
                card.value = 10;
                break;
            default:
                card.value = -1;  // 无效值
                break;
        }
    }

    // 将字符表示的花色转换为对应的枚举值
    switch (suit_let) {
        case 's':
            card.suit = SPADES;
            break;
        case 'h':
            card.suit = HEARTS;
            break;
        case 'd':
            card.suit = DIAMONDS;
            break;
        case 'c':
            card.suit = CLUBS;
            break;
        default:
            card.suit = NUM_SUITS;  // 无效花色
            break;
    }

    assert_card_valid(card);
    return card;
}

card_t card_from_num(unsigned c) {
    assert(c >= 0 && c < 52);
    int value = (int) c % 13 + 2;
    int suit = (int) c / 13;

    card_t random = {value, suit};

    return random;
}
