#include "cards.h"

int main(void) {

}
