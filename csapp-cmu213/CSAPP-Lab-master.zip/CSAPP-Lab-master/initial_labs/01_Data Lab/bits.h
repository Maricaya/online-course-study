//1
int bitXor(int, int);
int test_bitXor(int, int);
int tmin();
int test_tmin();
//2
int isTmax(int);
int test_isTmax(int);
int allOddBits();
int test_allOddBits();
int negate(int);
int test_negate(int);
//3
int isAsciiDigit(int);
int test_isAsciiDigit(int);
int conditional(int, int, int);
int test_conditional(int, int, int);
int isLessOrEqual(int, int);
int test_isLessOrEqual(int, int);
//4
int logicalNeg(int);
int test_logicalNeg(int);
int howManyBits(int);
int test_howManyBits(int);
//float
unsigned floatScale2(unsigned);
unsigned test_floatScale2(unsigned);
int floatFloat2Int(unsigned);
int test_floatFloat2Int(unsigned);
unsigned floatPower2(int);
unsigned test_floatPower2(int);
